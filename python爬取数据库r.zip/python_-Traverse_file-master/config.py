#!/usr/bin/python
# -*- coding: UTF-8 -*-
serverAddr = 'localhost'
databaseName = 'test'
user = 'root'
password = '123456'
keyWord = '_log'#搜索含关键字名字的文件夹，并将文件内容插入到数据库
GaomuTrue = 1#定制专用，目的是为了调整数据顺序再插入，直接插入使用非1即可
